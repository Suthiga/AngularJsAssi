angular.module('purchasefilters', []).filter('purchased', function(){
  return function(input){
    return input ? '\u2713' : '\u0058';
  };
});
